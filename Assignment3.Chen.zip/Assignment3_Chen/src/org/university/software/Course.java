package org.university.software;

import java.util.ArrayList;
import org.university.people.*;

public abstract class Course {
    protected String name;
    protected String courseNumber;
    protected int numCredits;
    protected ArrayList<Person> roster;
    protected Professor professor;
    protected org.university.hardware.Department department;

    public Course() {
        name = "";
        courseNumber = "";
        numCredits = 0;
        roster = new ArrayList<>();
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setCourseNumber(String number) {
        courseNumber = number;
    }

    public String getCourseNumber() {
        return courseNumber;
    }

    public void setNumCredits(int credits) {
        numCredits = credits;
    }

    public int getNumCredits() {
        return numCredits;
    }

    public void setDepartment(org.university.hardware.Department dept) {
        department = dept;
    }

    public org.university.hardware.Department getDepartment() {
        return department;
    }

    public void setProfessor(Professor p) {
        professor = p;
    }

    public Professor getProfessor() {
        return professor;
    }

    public void addStudentToRoster(Person p) {
        roster.add(p);
    }

    public ArrayList<Person> getRoster() {
        return roster;
    }

    public ArrayList<Person> getStudentRoster() {
        ArrayList<Person> list = new ArrayList<>();
        for (Person p : roster) {
            if (p instanceof Student) {
                list.add(p); 
            }
        }
        return list;
    }

    public void setCourseNumber(int number) {
        this.courseNumber = String.valueOf(number);
    }

    public void setCreditUnits(int credits) {
        this.setNumCredits(credits);
    }

    public int getCreditUnits() {
        return this.getNumCredits();
    }

    public String getCampusDisplayCode() {
        String cn = this.getCourseNumber();
        if (cn == null) cn = "";
        if (!cn.isEmpty() && Character.isLetter(cn.charAt(0))) return cn;
        String dept = (this.getDepartment() != null ? this.getDepartment().getDepartmentName() : "");
        if (dept == null) dept = "";
        return dept + cn;
    }

    public abstract boolean availableTo(Student aStudent);
}

