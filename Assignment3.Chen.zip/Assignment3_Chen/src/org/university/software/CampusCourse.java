package org.university.software;

import java.util.ArrayList;
import org.university.hardware.Classroom;
import org.university.people.Student;

public class CampusCourse extends Course {
    private ArrayList<Integer> schedule;
    private int maxStudents;
    private Classroom classroom;

    public CampusCourse() {
        super();
        schedule = new ArrayList<>();
        maxStudents = 0;
    }

    public void setSchedule(ArrayList<Integer> times) { this.schedule = times; }

    public void setSchedule(int[] times) {
        this.schedule = new ArrayList<>();
        if (times != null) for (int t : times) this.schedule.add(t);
    }

    public void setSchedule(int time) {
        if (this.schedule == null) this.schedule = new ArrayList<>();
        this.schedule.add(time);
    }

    public ArrayList<Integer> getSchedule() { return schedule; }

    public void setMaxStudents(int n) { maxStudents = n; }
    
    public int getMaxStudents() { return maxStudents; }

    public void setMaxCourseLimit(int limit) { this.setMaxStudents(limit); }
    
    public int getMaxCourseLimit() { return this.getMaxStudents(); }

    public void setRoomAssigned(Classroom c) {
        this.classroom = c;
        if (c != null) {
            ArrayList<CampusCourse> list = c.getCourses();
            if (!list.contains(this)) list.add(this);
        }
    }

    public Classroom getRoomAssigned() { return classroom; }

    @Override
    public boolean availableTo(Student aStudent) {
        return roster.size() < maxStudents;
    }

    public int conflictSlotWith(CampusCourse other) {
        for (int t1 : this.schedule)
            for (int t2 : other.schedule)
                if (t1 == t2) return t1;
        return -1;
    }

    public boolean conflictsWith(CampusCourse other) {
        return conflictSlotWith(other) != -1;
    }

    public static String toDaySlot(int code) {
        String[] W = { "Mon", "Tue", "Wed", "Thu", "Fri" };
        String[] S = {
            "8:00am to 9:15am",
            "9:30am to 10:45am",
            "11:00am to 12:15pm",
            "12:30pm to 1:45pm",
            "2:00pm to 3:15pm",
            "3:30pm to 4:45pm"
        };
        int d = (code / 100) - 1;
        int t = (code % 100) - 1;
        return W[d] + " " + S[t];
    }


    public String convertNumToTime(int code) { return toDaySlot(code); }

    public void printSchedule() {
        if (schedule == null) return;
        String roomName = (classroom == null ? "" : classroom.getRoomNumber());
        for (int time : schedule) {
            System.out.println(CampusCourse.toDaySlot(time) + " " + roomName);
        }
    }
}



