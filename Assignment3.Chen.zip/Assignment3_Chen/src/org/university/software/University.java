package org.university.software;

import java.util.ArrayList;
import org.university.hardware.*;
import org.university.people.*;

public class University {
    private String name;

    public ArrayList<Department> departmentList = new ArrayList<>();
    public ArrayList<Classroom> classroomList = new ArrayList<>();

    public University() {
        name = "";
    }

    public void setName(String n) { name = n; }
    
    public String getName() { return name; }

    public void addDepartment(Department d) { departmentList.add(d); }
    
    public void addClassroom(Classroom c) { classroomList.add(c); }

    public void printStudentList() {
        for (Department d : departmentList)
            for (Student s : d.getStudents())
                System.out.println(s.getName());
    }

    public void printProfessorList() {
        for (Department d : departmentList)
            for (Professor p : d.getProfessors())
                System.out.println(p.getName());
    }

    public void printStaffList() {
        for (Department d : departmentList)
            for (Staff s : d.getStaff())
                System.out.println(s.getName());
    }

    public void printCourseList() {
        for (Department d : departmentList)
            for (Course c : d.getCourses())
                System.out.println(c.getCampusDisplayCode() + " " + c.getName());
    }
}
