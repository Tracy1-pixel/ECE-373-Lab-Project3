package org.university.software;

import org.university.people.Student;

public class OnlineCourse extends Course {

    public OnlineCourse() {
        super();
    }

    @Override
    public boolean availableTo(Student aStudent) {
        int campusCredits = aStudent.getCampusCredits();
        if (campusCredits < 6) {
            System.out.println(
                "Student " + aStudent.getName() + " has only " + campusCredits +
                " on campus credits enrolled. Should have at least 6 credits registered before registering online courses."
            );
            return false;
        }
        return true;
    }


    public void setCreditUnits(int units) {
        this.setNumCredits(units);
    }
}
