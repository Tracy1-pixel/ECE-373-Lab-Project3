package org.university.hardware;

import java.util.ArrayList;
import org.university.people.*;
import org.university.software.*;

/**
 * Represents a University Department.
 * Keeps track of its professors, students, staff, and courses.
 */
public class Department {
    private String name;
    private ArrayList<Student> students;
    private ArrayList<Professor> professors;
    private ArrayList<Staff> staffMembers;
    private ArrayList<Course> courses;

    public Department() {
        this.name = "";
        students = new ArrayList<>();
        professors = new ArrayList<>();
        staffMembers = new ArrayList<>();
        courses = new ArrayList<>();
    }

    public void setDepartmentName(String name) { this.name = name; }
    public String getDepartmentName() { return name; }

    // ==== Adders with back-links (fixes NPE) ====
    public void addStudent(Student s) {
        students.add(s);
        if (s.getDepartment() == null) s.setDepartment(this);
    }

    public void addProfessor(Professor p) {
        professors.add(p);
        if (p.getDepartment() == null) p.setDepartment(this);
    }

    public void addStaff(Staff s) {
        staffMembers.add(s);
        if (s.getDepartment() == null) s.setDepartment(this);
    }

    public void addCourse(Course c) {
        courses.add(c);
        if (c.getDepartment() != this) c.setDepartment(this);
    }

    // ==== Getters ====
    public ArrayList<Student> getStudents() { return students; }
    public ArrayList<Professor> getProfessors() { return professors; }
    public ArrayList<Staff> getStaff() { return staffMembers; }
    public ArrayList<Course> getCourses() { return courses; }

    // ==== Print methods (no duplicate titles) ====
    public void printStudentList() {
        for (Student s : students) System.out.println(s.getName());
    }
    public void printProfessorList() {
        for (Professor p : professors) System.out.println(p.getName());
    }
    public void printStaffList() {
        for (Staff s : staffMembers) System.out.println(s.getName());
    }
    public void printCourseList() {
        for (Course c : courses) System.out.println(c.getCampusDisplayCode() + " " + c.getName());
    }

    // ==== Driver compatibility aliases ====
    public ArrayList<Professor> getProfessorList() { return this.getProfessors(); }
    public ArrayList<Student>   getStudentList()   { return this.getStudents(); }
    public ArrayList<Staff>     getStaffList()     { return this.getStaff(); }

    public ArrayList<CampusCourse> getCampusCourseList() {
        ArrayList<CampusCourse> list = new ArrayList<>();
        for (Course c : courses) if (c instanceof CampusCourse) list.add((CampusCourse) c);
        return list;
    }

    public ArrayList<OnlineCourse> getOnlineCourseList() {
        ArrayList<OnlineCourse> list = new ArrayList<>();
        for (Course c : courses) if (c instanceof OnlineCourse) list.add((OnlineCourse) c);
        return list;
    }
}



