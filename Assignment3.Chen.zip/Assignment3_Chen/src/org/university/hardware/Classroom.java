package org.university.hardware;

import java.util.ArrayList;
import org.university.software.CampusCourse;

public class Classroom {
    private String roomNumber;
    private ArrayList<CampusCourse> courses;

    public Classroom() {
        this.roomNumber = "";
        this.courses = new ArrayList<>();
    }

    public void setRoomNumber(String roomNumber) { this.roomNumber = roomNumber; }
    public String getRoomNumber() { return roomNumber; }
    public ArrayList<CampusCourse> getCourses() { return courses; }

    /** 给教室排课；若与已在本教室的课程冲突，按官方文案与顺序打印并拒绝添加 */
    public void addCourse(CampusCourse c) {
        for (CampusCourse existing : courses) {
            int timeCode = existing.conflictSlotWith(c);
            if (timeCode != -1) {
                System.out.println(
                    c.getCampusDisplayCode() + " conflicts with " + existing.getCampusDisplayCode() +
                    ". Conflicting time slot " + CampusCourse.toDaySlot(timeCode) + ". " +
                    c.getCampusDisplayCode() + " course cannot be added to " + this.getRoomNumber() + "'s Schedule."
                );
                return;
            }
        }
        courses.add(c);
        c.setRoomAssigned(this); // setRoomAssigned 内部已防重复加入
    }

    /** 仅打印条目（Driver 负责打印标题）；按时间槽全局排序 */
    public void printSchedule() {
        class Entry { int time; CampusCourse course; Entry(int t, CampusCourse c){ time=t; course=c; } }
        ArrayList<Entry> entries = new ArrayList<>();

        for (CampusCourse cc : courses) {
            ArrayList<Integer> sched = cc.getSchedule();
            if (sched == null) continue;
            for (int t : sched) entries.add(new Entry(t, cc));
        }

        entries.sort((a, b) -> Integer.compare(a.time, b.time));

        for (Entry e : entries) {
            System.out.println(
                CampusCourse.toDaySlot(e.time) + " " +
                e.course.getCampusDisplayCode() + " " + e.course.getName()
            );
        }
    }
}
