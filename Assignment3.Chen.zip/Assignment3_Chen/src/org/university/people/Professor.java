package org.university.people;

import org.university.hardware.Department;
import org.university.software.*;

public class Professor extends Employee {
    private Department department;
    private double salary;

    public Professor() {
        super();
        salary = 0;
    }

    public void setDepartment(Department d) { department = d; }
    public Department getDepartment() { return department; }

    public void setSalary(double s) { salary = s; }
    public double getSalary() { return salary; }

    @Override
    public double earns() { return salary / 26.0; }

    @Override
    public void raise(double percent) { salary += salary * percent / 100.0; }


    @Override
    public void addCourse(CampusCourse cCourse) {
        
        for (CampusCourse existing : campusCourses) {
            int slot = cCourse.conflictSlotWith(existing);
            if (slot != -1) {
                System.out.println(
                    cCourse.getName() + " course cannot be added to " + this.getName() +
                    "'s Schedule. " + cCourse.getName() + " conflicts with " + existing.getName() +
                    ". Conflicting time slot is " + CampusCourse.toDaySlot(slot) + "."
                );
                return;
            }
        }

        if (cCourse.getProfessor() != null) {
            System.out.println(
              "The professor " + this.getName() +
              " cannot be assigned to this campus course because professor " +
              cCourse.getProfessor().getName() + " is already assigned to the course " +
              cCourse.getName() + "."
            );
            return;
        }

        campusCourses.add(cCourse);
        cCourse.setProfessor(this);
    }

    @Override
    public void addCourse(OnlineCourse oCourse) {
        if (oCourse.getProfessor() != null) {
            System.out.println(
              "The professor cannot be assigned to this online course because professor " +
              oCourse.getProfessor().getName() + " is already assigned to the online course " +
              oCourse.getName() + "."
            );
            return;
        }
        onlineCourses.add(oCourse);
        oCourse.setProfessor(this);
    }

    @Override
    public void printSchedule() {
        for (org.university.software.CampusCourse c : campusCourses)
            for (int t : c.getSchedule())
                System.out.println(org.university.software.CampusCourse.toDaySlot(t) + " " +
                                   c.getCampusDisplayCode() + " " + c.getName());
        for (org.university.software.OnlineCourse o : onlineCourses)
            System.out.println(o.getCourseNumber() + " " + o.getName());
    }



}
