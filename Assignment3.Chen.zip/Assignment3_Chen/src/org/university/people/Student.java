package org.university.people;

import org.university.hardware.Department;
import org.university.software.*;

public class Student extends Person {
    private Department department;
    private int unitsCompleted;
    private int totalUnitsNeeded;
    private int currentlyEnrolledCredits;
    private double tuitionFee;

    public Student() {
        super();
        currentlyEnrolledCredits = 0;
    }

    public void setDepartment(Department d) { department = d; }
    
    public Department getDepartment() { return department; }

    public int getUnitsCompleted() { return unitsCompleted; }
    
    public void setUnitsCompleted(int units) { unitsCompleted = units; }

    public void setTotalUnitsNeeded(int units) { totalUnitsNeeded = units; }

    public int getRemainingUnits() {
        return totalUnitsNeeded - (unitsCompleted + currentlyEnrolledCredits);
    }

    public int getCurrentlyEnrolledCredits() { return currentlyEnrolledCredits; }

    public int getCampusCredits() {
        int total = 0;
        for (CampusCourse c : campusCourses) total += c.getNumCredits();
        return total;
    }

    @Override
    public void addCourse(CampusCourse cCourse) {
        for (CampusCourse existing : campusCourses) {
            int slot = cCourse.conflictSlotWith(existing);
            if (slot != -1) {
                System.out.println(
                    cCourse.getCampusDisplayCode() + " course cannot be added to " + this.getName() +
                    "'s Schedule. " + cCourse.getCampusDisplayCode() + " conflicts with " +
                    existing.getCampusDisplayCode() + ". Conflicting time slot is " +
                    CampusCourse.toDaySlot(slot) + "."
                );
                return;
            }
        }

        if (!cCourse.availableTo(this)) {
            System.out.println(
                this.getName() + " can't add Campus Course " +
                cCourse.getCampusDisplayCode() + " " + cCourse.getName() +
                ". Because this Campus course has enough student."
            );
            return;
        }

        campusCourses.add(cCourse);
        cCourse.addStudentToRoster(this);
        currentlyEnrolledCredits += cCourse.getNumCredits();
    }

    @Override
    public void addCourse(OnlineCourse oCourse) {
        if (!oCourse.availableTo(this)) {
            System.out.println(
                this.getName() + " can't add online Course " +
                oCourse.getCourseNumber() + " " + oCourse.getName() +
                ". Because this student doesn't have enough Campus course credit."
            );
            return;
        }
        onlineCourses.add(oCourse);
        oCourse.addStudentToRoster(this);
        currentlyEnrolledCredits += oCourse.getNumCredits();
    }

    public int getTuitionFee() {
        return (int) Math.round(calculateTuition());
    }

    public void dropCourse(CampusCourse cCourse) {
        if (!campusCourses.contains(cCourse)) {
            System.out.println("The course " + cCourse.getName() +
                    " could not be dropped because " + name +
                    " is not enrolled in " + cCourse.getName() + ".");
            return;
        }

        int campusCreditsAfterDrop = getCampusCredits() - cCourse.getNumCredits();
        if (!onlineCourses.isEmpty() && campusCreditsAfterDrop < 6) {
            System.out.println(name + " can't drop this CampusCourse, because this student doesn't have enough campus course credit to hold the online course");
            return;
        }

        campusCourses.remove(cCourse);
        currentlyEnrolledCredits -= cCourse.getNumCredits();
    }

    public void dropCourse(OnlineCourse oCourse) {
        if (!onlineCourses.contains(oCourse)) {
            System.out.println("The course " + oCourse.getName() +
                    " could not be dropped because " + name +
                    " is not enrolled in " + oCourse.getName() + ".");
            return;
        }
        onlineCourses.remove(oCourse);
        currentlyEnrolledCredits -= oCourse.getNumCredits();
    }

    public double calculateTuition() {
        tuitionFee = 0;
        for (CampusCourse c : campusCourses) tuitionFee += c.getNumCredits() * 300;
        for (OnlineCourse o : onlineCourses) {
            if (o.getNumCredits() == 3) tuitionFee += 2000;
            else if (o.getNumCredits() == 4) tuitionFee += 3000;
        }
        return tuitionFee;
    }

   
    public void setCompletedUnits(int units) { this.setUnitsCompleted(units); }

    public void setRequiredCredits(int units) { this.setTotalUnitsNeeded(units); }

    public int requiredToGraduate() { return this.getRemainingUnits(); }

    @Override
    public void printSchedule() {
        for (org.university.software.CampusCourse c : campusCourses)
            for (int t : c.getSchedule())
                System.out.println(org.university.software.CampusCourse.toDaySlot(t) + " " +
                                   c.getCampusDisplayCode() + " " + c.getName());
        for (org.university.software.OnlineCourse o : onlineCourses)
            System.out.println(o.getCourseNumber() + " " + o.getName());
    }
}

