package org.university.people;

import org.university.software.*;

public abstract class Employee extends Person {
    public Employee() {
        super();
    }

    public abstract double earns();

    public abstract void raise(double percent);
}

