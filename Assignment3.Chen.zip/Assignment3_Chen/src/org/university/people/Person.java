package org.university.people;

import java.util.ArrayList;
import org.university.software.CampusCourse;
import org.university.software.OnlineCourse;

public abstract class Person {
    protected String name;
    protected ArrayList<CampusCourse> campusCourses;
    protected ArrayList<OnlineCourse> onlineCourses;

    public Person() {
        name = "";
        campusCourses = new ArrayList<>();
        onlineCourses = new ArrayList<>();
    }

    public void setName(String name) { this.name = name; }
    public String getName() { return name; }

    public boolean detectConflict(CampusCourse aCourse) {
        for (CampusCourse existing : campusCourses) {
            if (existing.conflictsWith(aCourse)) return true;
        }
        return false;
    }

    public void printSchedule() {
        for (CampusCourse c : campusCourses) {
            for (int t : c.getSchedule()) {
                System.out.println(CampusCourse.toDaySlot(t) + " " +
                                   c.getCampusDisplayCode() + " " + c.getName());
            }
        }
        for (OnlineCourse o : onlineCourses) {
            System.out.println(o.getCourseNumber() + " " + o.getName());
        }
    }

    public boolean collisionDetection(CampusCourse aCourse) {
        for (CampusCourse existing : campusCourses) {
            int slot = aCourse.conflictSlotWith(existing);
            if (slot != -1) {
                System.out.println(
                    aCourse.getCampusDisplayCode() + " course cannot be added to " + this.getName() +
                    "'s Schedule. " + aCourse.getCampusDisplayCode() + " conflicts with " +
                    existing.getCampusDisplayCode() + ". Conflicting time slot is " +
                    CampusCourse.toDaySlot(slot) + "."
                );
                return true;
            }
        }
        return false;
    }

    public abstract void addCourse(CampusCourse cCourse);
    public abstract void addCourse(OnlineCourse oCourse);
}

