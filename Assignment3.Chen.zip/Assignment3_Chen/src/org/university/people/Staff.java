package org.university.people;

import org.university.hardware.Department;
import org.university.software.*;

public class Staff extends Employee {
    private Department department;
    private double payRate;
    private double hoursWorked;
    private double tuitionFee;

    public Staff() {
        super();
        payRate = 0;
        hoursWorked = 0;
        tuitionFee = 0;
    }

    public void setDepartment(Department d) { department = d; }
    public Department getDepartment() { return department; }

    public void setPayRate(double rate) { payRate = rate; }
    public double getPayRate() { return payRate; }

    public void setHoursWorked(double hours) { hoursWorked = hours; }
    public double getHoursWorked() { return hoursWorked; }

    public void setMonthlyHours(int hours) {
        this.setHoursWorked(hours);
    }

    @Override
    public double earns() { return payRate * hoursWorked; }

    @Override
    public void raise(double percent) { payRate += payRate * percent / 100.0; }

    @Override
    public void addCourse(CampusCourse c) {
        if (!campusCourses.isEmpty()) {
            CampusCourse old = campusCourses.get(0);
            System.out.println(
                old.getCampusDisplayCode() + " " + old.getName() +
                " is removed from " + this.getName() +
                "'s schedule(Staff can only take one class at a time). " +
                c.getCampusDisplayCode() + " " + c.getName() +
                " has been added to " + this.getName() + "'s Schedule."
            );
            campusCourses.clear();
        } else if (!onlineCourses.isEmpty()) {
            OnlineCourse old = onlineCourses.get(0);
            System.out.println(
                old.getCourseNumber() + " " + old.getName() +
                " is removed from " + this.getName() +
                "'s schedule(Staff can only take one class at a time). " +
                c.getCampusDisplayCode() + " " + c.getName() +
                " has been added to " + this.getName() + "'s Schedule."
            );
            onlineCourses.clear();
        }

        campusCourses.add(c);
        c.addStudentToRoster(this);
    }

    @Override
    public void addCourse(OnlineCourse o) {
        if (!onlineCourses.isEmpty()) {
            OnlineCourse old = onlineCourses.get(0);
            System.out.println(
                old.getCourseNumber() + " " + old.getName() +
                " is removed from " + this.getName() +
                "'s schedule(Staff can only take one class at a time). " +
                o.getCourseNumber() + " " + o.getName() +
                " has been added to " + this.getName() + "'s Schedule."
            );
            onlineCourses.clear();
        } else if (!campusCourses.isEmpty()) {
            CampusCourse old = campusCourses.get(0);
            System.out.println(
                old.getCampusDisplayCode() + " " + old.getName() +
                " is removed from " + this.getName() +
                "'s schedule(Staff can only take one class at a time). " +
                o.getCourseNumber() + " " + o.getName() +
                " has been added to " + this.getName() + "'s Schedule."
            );
            campusCourses.clear();
        }

        onlineCourses.add(o);
        o.addStudentToRoster(this);
    }

    public int getTuitionFee() {
        return (int) Math.round(calculateTuition());
    }

    public double calculateTuition() {
        tuitionFee = 0;
        for (CampusCourse c : campusCourses) tuitionFee += c.getNumCredits() * 300;
        for (OnlineCourse o : onlineCourses) {
            if (o.getNumCredits() == 3) tuitionFee += 2000;
            else if (o.getNumCredits() == 4) tuitionFee += 3000;
        }
        return tuitionFee;
    }

    @Override
    public void printSchedule() {
        for (CampusCourse c : campusCourses) {
            for (int t : c.getSchedule()) {
                System.out.println(CampusCourse.toDaySlot(t) + " " +
                                   c.getCampusDisplayCode() + " " + c.getName());
            }
        }
        for (OnlineCourse o : onlineCourses) {
            System.out.println(o.getCourseNumber() + " " + o.getName());
        }
    }
}



